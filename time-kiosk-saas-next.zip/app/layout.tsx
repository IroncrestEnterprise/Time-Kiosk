import "./globals.css";
import Link from "next/link";

export const metadata = {
  title: "Time Kiosk SaaS",
  description: "Multi-tenant time tracking kiosk with subscriptions",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <nav className="border-b bg-white">
          <div className="container h-16 flex items-center justify-between">
            <Link href="/" className="font-extrabold tracking-tight text-xl">TimeKiosk</Link>
            <div className="flex gap-3">
              <Link href="/pricing" className="btn">Pricing</Link>
              <Link href="/dashboard" className="btn btn-primary">Open App</Link>
            </div>
          </div>
        </nav>
        <main className="container py-8">{children}</main>
        <footer className="border-t mt-16">
          <div className="container py-6 text-sm text-slate-500">
            © {new Date().getFullYear()} TimeKiosk
          </div>
        </footer>
      </body>
    </html>
  );
}
