'use client';
import { useEffect, useState } from 'react';
import { createBrowserClient } from '@supabase/supabase-js';

const supabase = createBrowserClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);

type Employee = { id: string; name: string; pin?: string };

export default function EmployeesPage() {
  const [list, setList] = useState<Employee[]>([]);
  const [name, setName] = useState("");
  const [pin, setPin] = useState("");

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from('employees').select('id,name,pin').limit(100);
      setList(data || []);
    })();
  }, []);

  const add = async () => {
    await supabase.from('employees').insert({ name, pin /*, org_id: currentOrg */ });
    const { data } = await supabase.from('employees').select('id,name,pin').order('name');
    setList(data || []);
    setName(""); setPin("");
  };

  return (
    <div className="grid gap-6">
      <div className="card">
        <div className="font-bold">Add Employee</div>
        <div className="grid sm:grid-cols-3 gap-3 mt-3">
          <input placeholder="Name" value={name} onChange={e => setName(e.target.value)} />
          <input placeholder="PIN" value={pin} onChange={e => setPin(e.target.value)} />
          <button onClick={add} className="btn btn-primary">Save</button>
        </div>
      </div>
      <div className="card">
        <div className="font-bold mb-2">Employees</div>
        <ul className="divide-y">
          {list.map(e => (
            <li key={e.id} className="py-2 flex items-center justify-between">
              <span>{e.name}</span>
              <span className="text-slate-500 text-sm">PIN: {e.pin || '—'}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
