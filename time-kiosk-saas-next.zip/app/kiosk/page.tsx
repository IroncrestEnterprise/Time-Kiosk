'use client';
import { useState } from 'react';
import { createBrowserClient } from '@supabase/supabase-js';

const supabase = createBrowserClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);

export default function KioskPage() {
  const [pin, setPin] = useState("");
  const [status, setStatus] = useState("");

  const clock = async (direction: 'in' | 'out') => {
    setStatus("Processing...");
    const { data: emp } = await supabase.from('employees').select('id').eq('pin', pin).maybeSingle();
    if (!emp) { setStatus("Invalid PIN"); return; }
    if (direction === 'in') {
      await supabase.from('time_entries').insert({ employee_id: emp.id, clock_in: new Date().toISOString() /*, org_id: currentOrg*/ });
      setStatus("Clocked in.");
    } else {
      const { data: open } = await supabase.from('time_entries')
        .select('id').is('clock_out', null).eq('employee_id', emp.id).order('clock_in', { ascending: false }).limit(1);
      if (open && open.length) {
        await supabase.from('time_entries').update({ clock_out: new Date().toISOString() }).eq('id', open[0].id);
        setStatus("Clocked out.");
      } else {
        setStatus("No open shift.");
      }
    }
    setPin("");
  };

  return (
    <div className="max-w-md mx-auto card">
      <div className="text-xl font-bold">Time Kiosk</div>
      <div className="mt-4 grid gap-3">
        <input inputMode="numeric" placeholder="Enter PIN" value={pin} onChange={e => setPin(e.target.value)} />
        <div className="flex gap-3">
          <button className="btn btn-primary flex-1" onClick={() => clock('in')}>Clock In</button>
          <button className="btn flex-1" onClick={() => clock('out')}>Clock Out</button>
        </div>
        <div className="text-sm text-slate-600 h-6">{status}</div>
      </div>
    </div>
  );
}
