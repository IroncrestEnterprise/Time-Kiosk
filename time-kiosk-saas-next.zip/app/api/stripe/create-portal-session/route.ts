import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";

export async function POST(_req: NextRequest) {
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2024-06-20" });
  const stripeCustomerId = "cus_demo_replace_me"; // TODO: look up by org
  const session = await stripe.billingPortal.sessions.create({
    customer: stripeCustomerId,
    return_url: `${process.env.NEXT_PUBLIC_SITE_URL}/dashboard`,
  });
  return NextResponse.redirect(session.url, 303);
}
