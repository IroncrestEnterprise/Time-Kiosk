import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";

export async function POST(req: NextRequest) {
  const body = await req.formData();
  const plan = (body.get("plan") as string | null)?.toLowerCase();

  const priceMap: Record<string, string> = {
    "starter": process.env.STRIPE_PRICE_STARTER!,
    "pro": process.env.STRIPE_PRICE_PRO!
  };
  const price = priceMap[plan ?? "starter"];
  if (!price) return NextResponse.json({ error: "Unknown plan" }, { status: 400 });

  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2024-06-20" });
  const orgId = "org_demo_id"; // TODO: derive from session/JWT

  const session = await stripe.checkout.sessions.create({
    mode: "subscription",
    line_items: [{ price, quantity: 1 }],
    success_url: `${process.env.NEXT_PUBLIC_SITE_URL}/dashboard`,
    cancel_url: `${process.env.NEXT_PUBLIC_SITE_URL}/pricing`,
    subscription_data: { metadata: { org_id: orgId } },
    metadata: { org_id: orgId }
  });

  return NextResponse.redirect(session.url!, 303);
}
