import Link from "next/link";

export default function HomePage() {
  return (
    <section className="py-16">
      <div className="grid md:grid-cols-2 gap-8 items-center">
        <div>
          <h1 className="text-4xl font-black leading-tight">Clock‑in simplicity. Payroll‑ready records.</h1>
          <p className="mt-4 text-slate-600">A clean time‑tracking kiosk for crews, with pay‑period locking, exports, and subscription billing.</p>
          <div className="mt-6 flex gap-3">
            <Link href="/dashboard" className="btn btn-primary">Start Free Trial</Link>
            <Link href="/pricing" className="btn">View Pricing</Link>
          </div>
          <ul className="mt-8 text-slate-700 list-disc pl-4 space-y-1">
            <li>Multi‑tenant (organizations & roles)</li>
            <li>Supabase Auth + Postgres with RLS</li>
            <li>Stripe subscriptions with trials</li>
          </ul>
        </div>
        <div className="card">
          <div className="text-xl font-bold mb-2">Kiosk Preview</div>

          <div className="grid gap-3">
            <input placeholder="Enter PIN" />
            <button className="btn btn-primary">Clock In</button>
            <button className="btn">View Records</button>
          </div>
        </div>
      </div>
    </section>
  );
}
