export default function PricingPage() {
  return (
    <div className="grid md:grid-cols-3 gap-6">
      {[
        { name: "Free Trial", price: "$0", planKey: "starter", features: ["14 days", "All features"], cta: "Start Trial" },
        { name: "Starter", price: "$19/mo", planKey: "starter", features: ["Up to 10 employees", "Exports", "Email support"], cta: "Choose Starter" },
        { name: "Pro", price: "$49/mo", planKey: "pro", features: ["Up to 50 employees", "Pay-period locking", "Priority support"], cta: "Choose Pro" },
      ].map((t) => (
        <div className="card" key={t.name}>
          <div className="text-sm text-slate-500">{t.name}</div>
          <div className="text-3xl font-extrabold mt-1">{t.price}</div>
          <ul className="mt-4 text-slate-700 list-disc pl-4 space-y-1">
            {t.features.map((f) => <li key={f}>{f}</li>)}
          </ul>
          <form action="/api/stripe/create-checkout-session" method="post" className="mt-6">
            <input type="hidden" name="plan" value={t.planKey} />
            <button className="btn btn-primary w-full">{t.cta}</button>
          </form>
        </div>
      ))}
    </div>
  );
}
