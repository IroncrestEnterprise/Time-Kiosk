import Link from "next/link";

export default function Dashboard() {
  return (
    <div className="grid md:grid-cols-3 gap-6">
      <div className="card">
        <div className="font-bold">Employees</div>
        <div className="text-sm text-slate-500">Add, edit, and set PINs</div>
        <Link href="/employees" className="btn mt-4">Manage</Link>
      </div>
      <div className="card">
        <div className="font-bold">Pay Periods</div>
        <div className="text-sm text-slate-500">Define start/end, lock when closed</div>
        <Link href="/pay-periods" className="btn mt-4">Open</Link>
      </div>
      <div className="card">
        <div className="font-bold">Billing</div>
        <div className="text-sm text-slate-500">Manage your plan & invoices</div>
        <form action="/api/stripe/create-portal-session" method="post" className="mt-4">
          <button className="btn">Open Customer Portal</button>
        </form>
      </div>
    </div>
  );
}
