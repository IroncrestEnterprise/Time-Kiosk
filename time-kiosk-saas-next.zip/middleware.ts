import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(_req: NextRequest) {
  // TODO: Verify user session & org status; redirect to /pricing or /billing when needed.
  return NextResponse.next();
}

export const config = {
  matcher: ['/dashboard/:path*', '/employees/:path*', '/kiosk/:path*', '/pay-periods/:path*']
};
