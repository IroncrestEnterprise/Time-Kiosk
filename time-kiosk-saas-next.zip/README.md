# Time Kiosk — SaaS (Next.js + Supabase + Stripe)

A multi-tenant time tracking kiosk with subscriptions.

## Tech
- Next.js (App Router)
- Supabase (Auth + Postgres + RLS)
- Stripe Billing (Checkout + Customer Portal)
- TailwindCSS

## Setup

1. **Supabase**
   - Create project, copy `NEXT_PUBLIC_SUPABASE_URL` & `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
   - Create a service role key and set `SUPABASE_SERVICE_ROLE_KEY` (server only).
   - Run `supabase/schema.sql` in the SQL editor.

2. **Stripe**
   - Create products/prices; set:
     - `STRIPE_PRICE_STARTER`
     - `STRIPE_PRICE_PRO`
   - Set `STRIPE_SECRET_KEY` and add a webhook to `/api/stripe/webhook`.
   - Use Stripe CLI for local testing if needed.

3. **Env**
   - Copy `.env.example` to `.env.local` and fill values.
   - Ensure `NEXT_PUBLIC_SITE_URL` matches your domain in prod.

4. **Run**
   ```bash
   npm i
   npm run dev
   ```

5. **Deploy (Vercel)**
   - Add env vars.
   - Confirm webhook route works.

## Notes
- RLS and middleware are permissive for speed—tighten before production (enforce org_id per row and membership checks).
- Replace placeholder org/customer resolution in the Stripe routes with your real logic.
