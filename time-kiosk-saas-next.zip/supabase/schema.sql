create extension if not exists "uuid-ossp";
create extension if not exists "pgcrypto";

create table if not exists organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  stripe_customer_id text,
  plan text check (plan in ('free','starter','pro')) default 'free',
  status text check (status in ('trialing','active','past_due','canceled')) default 'trialing',
  created_at timestamptz default now()
);

create table if not exists profiles (
  user_id uuid primary key,
  email text unique,
  default_org uuid references organizations(id)
);

create table if not exists memberships (
  user_id uuid references auth.users(id) on delete cascade,
  org_id uuid references organizations(id) on delete cascade,
  role text check (role in ('owner','admin','member')) default 'member',
  primary key (user_id, org_id)
);

create table if not exists employees (
  id uuid primary key default gen_random_uuid(),
  org_id uuid references organizations(id) on delete cascade not null,
  name text not null,
  pin text
);

create table if not exists time_entries (
  id uuid primary key default gen_random_uuid(),
  org_id uuid references organizations(id) on delete cascade not null,
  employee_id uuid references employees(id) on delete set null,
  clock_in timestamptz not null,
  clock_out timestamptz,
  notes text
);

create table if not exists pay_periods (
  id uuid primary key default gen_random_uuid(),
  org_id uuid references organizations(id) on delete cascade not null,
  start_date date not null,
  end_date date not null,
  closed_at timestamptz
);

alter table organizations enable row level security;
alter table profiles enable row level security;
alter table memberships enable row level security;
alter table employees enable row level security;
alter table time_entries enable row level security;
alter table pay_periods enable row level security;

-- TODO: Replace permissive policies with secure membership checks
create policy "employees read" on employees for select using (true);
create policy "employees write" on employees for all using (true) with check (true);
create policy "entries read" on time_entries for select using (true);
create policy "entries write" on time_entries for all using (true) with check (true);
